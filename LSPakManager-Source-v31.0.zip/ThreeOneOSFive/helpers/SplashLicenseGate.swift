import SwiftUI
import AVFoundation
import UIKit

// ============================================================
// v21.0 · 启动视频 + 卡密验证门
// 1. 全屏播放包内 splash.mp4（120 帧原片），播完定格在最后一帧
// 2. 定格画面上叠卡密验证页：输入 → 服务端校验 → 进去了
// 3. 验过一次就记住（钥匙串），下次启动直接进；到期或被停用就锁回来
// ============================================================

struct SplashLicenseGateView: View {
    @EnvironmentObject private var license: LicenseManager
    /// 视频已经播过了（比如到期后被锁回来）就不再重播，直接出输入框
    var skipVideo: Bool = false
    /// 视频播完 / 兜底超时时通知外层：可以进主界面了
    var onVideoEnd: () -> Void = {}
    @State private var key = ""
    @State private var videoDone = false
    @FocusState private var keyFocused: Bool

    // v25.0 · 后台「卡密窗口」改的样式，进来就拉一次，拉不到用上次缓存的
    @StateObject private var themeStore = LicenseThemeStore.shared
    private var th: LicenseTheme { themeStore.theme }

    // 这三个色名字没改，值改成后台可配的（后台没配就是原来那套霓虹绿）
    private var cyan: Color { LSThemeColor.color(th.primary, fallback: Color(red: 0.16, green: 0.92, blue: 0.52)) }
    private var cyanDeep: Color { LSThemeColor.color(th.secondary, fallback: Color(red: 0.07, green: 0.64, blue: 0.56)) }
    private var accentTail: Color { LSThemeColor.color(th.accent, fallback: Color(red: 0.56, green: 0.44, blue: 0.96)) }
    private var inputInk: Color { LSThemeColor.color(th.inputText, fallback: Color.black.opacity(0.86)) }
    /// 后台配了背景图就用它的尺寸判断：手机铺满、平板居中不裁
    private var customBG: UIImage? { themeStore.backgroundImage }
    private var customLogo: UIImage? { themeStore.logoImage }

    private var trimmedKey: String {
        key.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    var body: some View {
        GeometryReader { geo in
            // v24.0 · 手机 / iPad 同一套：iPad 和横屏把内容收成一列居中，不再被拉宽变形
            let wide = geo.size.width >= 700
            let columnMax: CGFloat = wide ? 480 : .infinity
            let sidePad: CGFloat = wide ? 28 : 26
            ZStack {
                // v28.0 · 视频没加载出来 / 包里缺素材时，这里也有一层品牌底色，不会再是一片纯黑
                LinearGradient(
                    colors: [
                        Color(red: 0.03, green: 0.13, blue: 0.10),
                        Color(red: 0.01, green: 0.06, blue: 0.06),
                        Color(red: 0.00, green: 0.02, blue: 0.03)
                    ],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                .ignoresSafeArea()

                // v25.0 · 后台配了卡密窗口背景图就先垫在最底下：视频播完淡出，露出这张图
                if let bg = customBG {
                    LSFillImage(image: bg)
                        .ignoresSafeArea()
                        .opacity(videoDone ? 1 : 0)
                        .animation(.easeOut(duration: 0.6), value: videoDone)
                        .allowsHitTesting(false)
                }

                // 视频层始终在：播完就定格在最后一帧，卡密页压在这一帧上，不会切回黑底
                // v27.0 · 需要输卡密时不播片，直接出验证页（要的就是快）
                if !skipVideo {
                    SplashVideoBackground(onFinished: { finishVideo() })
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                        .ignoresSafeArea()
                        .opacity(customBG != nil && videoDone ? 0 : 1)
                        .animation(.easeOut(duration: 0.6), value: videoDone)
                        .allowsHitTesting(false)
                }

                LinearGradient(
                    colors: [
                        Color.black.opacity(th.dim * 0.55),
                        Color.black.opacity(th.dim),
                        Color.black.opacity(min(0.96, th.dim * 1.42))
                    ],
                    startPoint: .top,
                    endPoint: .bottom
                )
                .ignoresSafeArea()
                .allowsHitTesting(false)

                ScrollView(showsIndicators: false) {
                    VStack(spacing: 0) {
                        if let logo = customLogo {
                            Image(uiImage: logo)
                                .resizable()
                                .scaledToFit()
                                .frame(width: 92, height: 92)
                                .shadow(color: cyan.opacity(0.42), radius: 18, y: 8)
                                .padding(.top, 58)
                        } else if th.showShield {
                            shieldIcon
                                .padding(.top, 58)
                        }

                        Text(th.title)
                            .font(.system(size: 34, weight: .heavy))
                            .foregroundStyle(.white)
                            .multilineTextAlignment(.center)
                            .padding(.top, th.showShield || customLogo != nil ? 16 : 66)

                        Text(th.subtitle)
                            .font(.system(size: 13, weight: .medium))
                            .foregroundStyle(.white.opacity(0.60))
                            .multilineTextAlignment(.center)
                            .padding(.top, 7)

                        Text(th.section)
                            .font(.system(size: 15, weight: .semibold))
                            .foregroundStyle(.white.opacity(0.72))
                            .padding(.top, 42)

                        VStack(alignment: .leading, spacing: 9) {
                            Text(th.fieldLabel)
                                .font(.system(size: 13, weight: .medium))
                                .foregroundStyle(.white.opacity(0.66))

                            TextField(th.placeholder, text: $key)
                                .focused($keyFocused)
                                .keyboardType(.asciiCapable)
                                .textInputAutocapitalization(.characters)
                                .autocorrectionDisabled()
                                .submitLabel(.done)
                                .onSubmit { submit() }
                                .onChange(of: key) { newValue in
                                    let cleaned = newValue.uppercased().filter { !$0.isWhitespace }
                                    if cleaned != newValue { key = cleaned }
                                }
                                .font(.system(size: 16, weight: .medium, design: .monospaced))
                                .foregroundStyle(inputInk)
                                .tint(cyanDeep)
                                .padding(.horizontal, 18)
                                .frame(height: 54)
                                .background(
                                    RoundedRectangle(cornerRadius: CGFloat(th.corner) - 1, style: .continuous)
                                        .fill(Color.white.opacity(0.95))
                                )
                                .overlay(
                                    RoundedRectangle(cornerRadius: CGFloat(th.corner) - 1, style: .continuous)
                                        .stroke(cyan.opacity(0.60), lineWidth: 1.2)
                                )
                        }
                        .padding(.top, 20)

                        Button(action: submit) {
                            HStack(spacing: 9) {
                                if license.isBusy {
                                    ProgressView()
                                        .progressViewStyle(.circular)
                                        .tint(.white)
                                        .scaleEffect(0.85)
                                }
                                Text(license.isBusy ? "验证中…" : th.button)
                                    .font(.system(size: 17, weight: .bold))
                                    .tracking(0.5)
                            }
                            .foregroundStyle(.white)
                            .frame(maxWidth: .infinity, minHeight: 56)
                            .background(
                                RoundedRectangle(cornerRadius: CGFloat(th.corner), style: .continuous)
                                    .fill(
                                        th.buttonGradient
                                        ? AnyShapeStyle(LinearGradient(
                                            colors: [cyan, accentTail],
                                            startPoint: .leading,
                                            endPoint: .trailing
                                          ))
                                        : AnyShapeStyle(cyan)
                                    )
                            )
                            .shadow(color: cyan.opacity(0.35), radius: 16, y: 7)
                        }
                        .buttonStyle(.plain)
                        .disabled(trimmedKey.isEmpty || license.isBusy)
                        .opacity(trimmedKey.isEmpty ? 0.55 : 1)
                        .padding(.top, 22)

                        if let text = statusText {
                            statusBox(text)
                                .padding(.top, 14)
                        }

                        Text(th.footer)
                            .font(.system(size: 12, weight: .medium))
                            .foregroundStyle(.white.opacity(0.45))
                            .multilineTextAlignment(.center)
                            .padding(.top, 20)

                        if license.state == .expired || license.hasSavedCode {
                            Button("换一个卡密") {
                                license.deactivate()
                                key = ""
                            }
                            .font(.system(size: 12, weight: .semibold))
                            .foregroundStyle(cyan.opacity(0.85))
                            .buttonStyle(.plain)
                            .padding(.top, 12)
                        }

                        Spacer(minLength: 46)

                        Text(th.copyright)
                            .font(.system(size: 11, weight: .medium))
                            .foregroundStyle(.white.opacity(0.34))
                            .multilineTextAlignment(.center)
                            .padding(.bottom, 30)
                    }
                    .padding(.horizontal, sidePad)
                    .frame(maxWidth: columnMax)
                    .frame(maxWidth: .infinity)
                }
                .scrollDismissesKeyboard(.interactively)

                if license.state == .checking {
                    VStack(spacing: 10) {
                        ProgressView().tint(cyan)
                        Text("正在核对授权…")
                            .font(.system(size: 12, weight: .medium))
                            .foregroundStyle(.white.opacity(0.6))
                    }
                    .padding(18)
                    .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .onAppear {
            // v25.0 · 后台改了就换：拉不到就继续用上次缓存的（不挡人）
            Task { await themeStore.refresh() }
            if skipVideo {
                videoDone = true
            } else {
                // 视频加载失败 / 卡住时的兜底，别把用户永远卡在黑屏
                DispatchQueue.main.asyncAfter(deadline: .now() + 17) {
                    finishVideo()
                }
            }
        }
        .onChange(of: skipVideo) { done in
            // v27.0 · 开场过场一结束就停片，别在输入框后面一直动
            if done { finishVideo() }
        }
        .preferredColorScheme(.dark)
    }

    private func finishVideo() {
        guard !videoDone else { return }
        withAnimation(.easeOut(duration: 0.45)) {
            videoDone = true
        }
        onVideoEnd()
    }

    // MARK: - 组件

    private var shieldIcon: some View {
        ZStack {
            LSHexShield()
                .fill(
                    LinearGradient(
                        colors: [cyan.opacity(0.98), cyanDeep],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
                .frame(width: 78, height: 90)
                .shadow(color: cyan.opacity(0.50), radius: 20, y: 8)

            Image(systemName: "checkmark")
                .font(.system(size: 30, weight: .bold))
                .foregroundStyle(.white.opacity(0.96))
                .offset(y: -3)
        }
    }

    private var statusText: String? {
        if let message = license.message, !message.isEmpty { return message }
        return nil
    }

    private func statusBox(_ text: String) -> some View {
        Text(text)
            .font(.system(size: 12.5, weight: .semibold))
            .foregroundStyle(Color(red: 1.0, green: 0.62, blue: 0.62))
            .multilineTextAlignment(.center)
            .frame(maxWidth: .infinity)
            .padding(.horizontal, 14)
            .padding(.vertical, 11)
            .background(
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .fill(Color.white.opacity(0.10))
            )
            .overlay(
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .stroke(Color.white.opacity(0.12), lineWidth: 1)
            )
    }

    private func submit() {
        let code = trimmedKey
        guard !code.isEmpty, !license.isBusy else { return }
        keyFocused = false
        Task { await license.activate(code: code) }
    }
}

/// 六边形盾牌 —— 图上那个标的形状
struct LSHexShield: Shape {
    func path(in rect: CGRect) -> Path {
        var p = Path()
        let w = rect.width
        let h = rect.height
        p.move(to: CGPoint(x: rect.minX + w * 0.50, y: rect.minY))
        p.addLine(to: CGPoint(x: rect.minX + w * 0.94, y: rect.minY + h * 0.18))
        p.addLine(to: CGPoint(x: rect.minX + w * 0.94, y: rect.minY + h * 0.56))
        p.addQuadCurve(
            to: CGPoint(x: rect.minX + w * 0.50, y: rect.minY + h),
            control: CGPoint(x: rect.minX + w * 0.86, y: rect.minY + h * 0.84)
        )
        p.addQuadCurve(
            to: CGPoint(x: rect.minX + w * 0.06, y: rect.minY + h * 0.56),
            control: CGPoint(x: rect.minX + w * 0.14, y: rect.minY + h * 0.84)
        )
        p.addLine(to: CGPoint(x: rect.minX + w * 0.06, y: rect.minY + h * 0.18))
        p.closeSubpath()
        return p
    }
}

/// 盾牌形状（上宽下尖，和验证页顶部那个标一致）
struct LSSplashShield: Shape {
    func path(in rect: CGRect) -> Path {
        var p = Path()
        let w = rect.width
        let h = rect.height
        p.move(to: CGPoint(x: rect.minX + w * 0.17, y: rect.minY))
        p.addLine(to: CGPoint(x: rect.minX + w * 0.83, y: rect.minY))
        p.addLine(to: CGPoint(x: rect.minX + w, y: rect.minY + h * 0.16))
        p.addLine(to: CGPoint(x: rect.minX + w, y: rect.minY + h * 0.55))
        p.addQuadCurve(
            to: CGPoint(x: rect.minX + w * 0.5, y: rect.minY + h),
            control: CGPoint(x: rect.minX + w * 0.86, y: rect.minY + h * 0.84)
        )
        p.addQuadCurve(
            to: CGPoint(x: rect.minX, y: rect.minY + h * 0.55),
            control: CGPoint(x: rect.minX + w * 0.14, y: rect.minY + h * 0.84)
        )
        p.addLine(to: CGPoint(x: rect.minX, y: rect.minY + h * 0.16))
        p.closeSubpath()
        return p
    }
}

// MARK: - 视频背景（播完定格最后一帧）

/// v27.0 · 已授权时的纯开场过场：只播启动片，不显示任何输入框
struct SplashOpeningView: View {
    var body: some View {
        ZStack {
            // v31.0 · 不再是纯黑：和系统启动屏同一个品牌深墨绿，视频没起来时也不会「黑一下」
            Color(red: 0x06 / 255.0, green: 0x14 / 255.0, blue: 0x0C / 255.0)
            SplashVideoBackground()
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .ignoresSafeArea()
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}

struct SplashVideoBackground: UIViewRepresentable {
    var onFinished: (() -> Void)? = nil
    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> SplashVideoPlayerView {
        let view = SplashVideoPlayerView()
        context.coordinator.handler = onFinished
        view.onFinished = { context.coordinator.fire() }
        return view
    }

    func updateUIView(_ uiView: SplashVideoPlayerView, context: Context) {
        context.coordinator.handler = onFinished
        uiView.startIfNeeded()
    }

    final class Coordinator {
        var handler: (() -> Void)?
        private var fired = false

        func fire() {
            guard !fired else { return }
            fired = true
            handler?()
        }
    }
}

final class SplashVideoPlayerView: UIView {
    // v26.0 · 真满屏覆盖
    // 手机竖屏走竖版启动片 splash.mp4，iPad 竖屏 / 所有横屏自动换横版启动片 splashWide.mp4，
    // 两者都是「铺满整屏 + 裁掉多余边」，不再有居中留边，也不再有模糊垫底，任何比例都不露白、不拉伸变形。
    //
    // v31.0 · 治「进软件先黑一下」：
    //   1) 底色不再是纯黑，换成和系统启动屏同一个品牌色（#06140C），冷启动到入场全程一色，肉眼看不到断层
    //   2) 视频解码出第一帧之前，先把片子第一帧的静态图（SplashFirst / SplashFirstWide）画上去，
    //      起播再慢用户看到的也是画面，不是黑屏；视频就绪后再 0.2 秒淡入接管
    //   3) 关闭自动等待缓冲 + 只缓冲 1 秒，起播更快
    private let playerLayer = AVPlayerLayer()
    private let posterView = UIImageView()
    private var player: AVPlayer?
    private var playerItem: AVPlayerItem?
    private var endObserver: NSObjectProtocol?
    private var statusObservation: NSKeyValueObservation?
    private var started = false
    private var posterApplied = false
    /// 品牌深墨绿，和 Info.plist 里的 LaunchBg 完全一致
    static let brandInk = UIColor(red: 0x06 / 255.0, green: 0x14 / 255.0, blue: 0x0C / 255.0, alpha: 1)
    /// 播完并定格后回调一次
    var onFinished: (() -> Void)?

    override init(frame: CGRect) {
        super.init(frame: frame)
        setup()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setup()
    }

    private var isWideLayout: Bool {
        let ratio = bounds.width / max(bounds.height, 1)
        return ratio > (9.0 / 16.0) * 1.25
    }

    private func setup() {
        backgroundColor = Self.brandInk
        clipsToBounds = true
        isUserInteractionEnabled = false

        posterView.contentMode = .scaleAspectFill
        posterView.clipsToBounds = true
        posterView.backgroundColor = Self.brandInk
        posterView.isUserInteractionEnabled = false
        addSubview(posterView)

        playerLayer.videoGravity = .resizeAspectFill
        playerLayer.opacity = 0          // 第一帧就绪后再淡入，避免空图层闪黑
        layer.addSublayer(playerLayer)
    }

    /// 先把启动片第一帧顶上（毫秒级，走资源目录，不用解码视频）
    private func applyPosterIfNeeded() {
        guard !posterApplied, bounds.width > 1 else { return }
        posterApplied = true
        let wide = isWideLayout
        let image = UIImage(named: wide ? "SplashFirstWide" : "SplashFirst")
            ?? UIImage(named: "SplashFirst")
            ?? UIImage(named: "SplashFirstWide")
        posterView.image = image
        if image == nil { posterView.backgroundColor = Self.brandInk }
        posterView.frame = bounds
    }

    /// 竖屏取竖版素材，宽屏取横版素材；包里缺哪个就退回另一个，永不黑屏
    private func videoURL() -> URL? {
        if isWideLayout, let u = Bundle.main.url(forResource: "splashWide", withExtension: "mp4") {
            return u
        }
        return Bundle.main.url(forResource: "splash", withExtension: "mp4")
            ?? Bundle.main.url(forResource: "splashWide", withExtension: "mp4")
    }

    func startIfNeeded() {
        guard !started else { return }
        guard bounds.width > 1, bounds.height > 1 else { return }
        started = true

        applyPosterIfNeeded()

        guard let url = videoURL() else {
            // 包里没有视频：静态首帧留着当画面，不崩、不黑、也别把用户卡在这
            DispatchQueue.main.async { [weak self] in self?.onFinished?() }
            return
        }

        try? AVAudioSession.sharedInstance().setCategory(.ambient, mode: .default, options: [.mixWithOthers])

        let item = AVPlayerItem(asset: AVURLAsset(url: url))
        // 只缓冲 1 秒、不等缓冲满就起播：这两项直接影响「点开之后那一下黑屏有多久」
        item.preferredForwardBufferDuration = 1
        let p = AVPlayer(playerItem: item)
        p.isMuted = true
        p.actionAtItemEnd = .pause
        p.automaticallyWaitsToMinimizeStalling = false
        player = p
        playerItem = item
        playerLayer.player = p

        // 解码器真的就绪了再把视频层淡进来；在那之前静态首帧一直盖着，绝不会出现黑场
        statusObservation = item.observe(\.status, options: [.new, .initial]) { [weak self] observed, _ in
            guard observed.status == .readyToPlay else { return }
            DispatchQueue.main.async {
                guard let self else { return }
                // 再给解码器一帧的时间，确保淡入时已经有画面
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.12) {
                    UIView.animate(withDuration: 0.2, delay: 0, options: [.beginFromCurrentState]) {
                        self.playerLayer.opacity = 1
                    }
                }
                self.statusObservation?.invalidate()
                self.statusObservation = nil
            }
        }

        endObserver = NotificationCenter.default.addObserver(
            forName: .AVPlayerItemDidPlayToEndTime,
            object: item,
            queue: .main
        ) { [weak p, weak item] _ in
            guard let p else { return }
            // 停在最后一帧：不循环、不黑屏
            let duration = item?.duration.seconds ?? 0
            if duration.isFinite, duration > 0.1 {
                p.seek(
                    to: CMTime(seconds: max(0, duration - 0.05), preferredTimescale: 600),
                    toleranceBefore: .zero,
                    toleranceAfter: .zero
                ) { _ in
                    p.pause()
                    self.onFinished?()
                }
            } else {
                p.pause()
                self.onFinished?()
            }
        }

        p.playImmediately(atRate: 1)
    }

    override func layoutSubviews() {
        super.layoutSubviews()

        applyPosterIfNeeded()

        CATransaction.begin()
        CATransaction.setDisableActions(true)
        playerLayer.frame = bounds
        posterView.frame = bounds
        CATransaction.commit()

        // 尺寸出来之前拿不到屏幕比例，这里补一次启动
        if !started {
            startIfNeeded()
        }
    }

    deinit {
        statusObservation?.invalidate()
        if let endObserver {
            NotificationCenter.default.removeObserver(endObserver)
        }
    }
}

// MARK: - 后台自定义背景图（满屏适配）

/// 后台「卡密窗口」上传的那张图。
/// v26.0 · 不管图片什么比例，一律「铺满整屏 + 裁掉多余边」：
/// 不留白、不模糊垫底、不拉伸，手机竖屏和 iPad 横屏都是满屏。
struct LSFillImage: View {
    let image: UIImage

    var body: some View {
        GeometryReader { geo in
            let w = max(geo.size.width, 1)
            let h = max(geo.size.height, 1)

            Image(uiImage: image)
                .resizable()
                .interpolation(.high)
                .scaledToFill()
                .frame(width: w, height: h)
                .clipped()
        }
    }
}
