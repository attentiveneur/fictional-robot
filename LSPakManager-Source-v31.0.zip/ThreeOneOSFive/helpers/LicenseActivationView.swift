import SwiftUI

// v21.0：卡密页已合并到「启动视频 + 卡密门」(SplashLicenseGateView)。
// 这个旧入口保留成空壳，避免工程里原有的文件引用失配。
struct LicenseActivationView: View {
    var body: some View {
        SplashLicenseGateView()
    }
}
